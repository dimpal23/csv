package com.batch.chartexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChartexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChartexampleApplication.class, args);
	}

}
